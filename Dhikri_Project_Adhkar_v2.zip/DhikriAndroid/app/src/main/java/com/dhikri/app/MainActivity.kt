package com.dhikri.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

private val Forest = Color(0xFF102F29)
private val Forest2 = Color(0xFF1C493C)
private val Gold = Color(0xFFE5C98C)
private val Cream = Color(0xFFF4EEDC)
private val Muted = Color(0xFFB9C9BE)

private val prayers = listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")


private data class DhikrItem(
    val title: String,
    val text: String,
    val repetitions: Int,
    val source: String
)

private val adhkarSections = listOf(
    "أذكار الصباح",
    "أذكار المساء",
    "أذكار بعد الصلاة"
)

private val morningEveningAdhkar = listOf(
    DhikrItem(
        "آية الكرسي",
        "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ...",
        1,
        "سورة البقرة: 255"
    ),
    DhikrItem(
        "سورة الإخلاص",
        "قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ",
        3,
        "سورة الإخلاص؛ تُقرأ ثلاث مرات صباحاً ومساءً"
    ),
    DhikrItem(
        "سورة الفلق",
        "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ۝ مِن شَرِّ مَا خَلَقَ ۝ وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ ۝ وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ۝ وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ",
        3,
        "سورة الفلق؛ تُقرأ ثلاث مرات صباحاً ومساءً"
    ),
    DhikrItem(
        "سورة الناس",
        "قُلْ أَعُوذُ بِرَبِّ النَّاسِ ۝ مَلِكِ النَّاسِ ۝ إِلَٰهِ النَّاسِ ۝ مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ۝ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ۝ مِنَ الْجِنَّةِ وَالنَّاسِ",
        3,
        "سورة الناس؛ تُقرأ ثلاث مرات صباحاً ومساءً"
    ),
    DhikrItem(
        "سيد الاستغفار",
        "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي، فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ",
        1,
        "صحيح البخاري، حديث سيد الاستغفار"
    ),
    DhikrItem(
        "ذكر الحفظ",
        "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ",
        3,
        "سنن أبي داود والترمذي؛ ثلاث مرات صباحاً ومساءً"
    )
)

private val afterPrayerAdhkar = listOf(
    DhikrItem("الاستغفار", "أَسْتَغْفِرُ اللَّهَ", 3, "صحيح مسلم، من أذكار دبر الصلاة"),
    DhikrItem("دعاء السلام", "اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ", 1, "صحيح مسلم"),
    DhikrItem("التسبيح", "سُبْحَانَ اللَّهِ", 33, "صحيح مسلم؛ مع التحميد والتكبير دبر الصلاة"),
    DhikrItem("التحميد", "الْحَمْدُ لِلَّهِ", 33, "صحيح مسلم؛ مع التسبيح والتكبير دبر الصلاة"),
    DhikrItem("التكبير", "اللَّهُ أَكْبَرُ", 33, "صحيح مسلم؛ ويُتم المائة بقول: لا إله إلا الله وحده لا شريك له...")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = DhikriStore(this)
        setContent { DhikriApp(store) }
    }
}

class DhikriStore(context: Context) {
    private val prefs = context.getSharedPreferences("dhikri_daily", Context.MODE_PRIVATE)

    fun load(): Pair<String, Map<String, Int>> {
        val today = LocalDate.now().toString()
        val savedDate = prefs.getString("date", "") ?: ""
        if (savedDate != today) {
            prefs.edit().clear().putString("date", today).apply()
            return today to prayers.associateWith { 0 }
        }
        return today to prayers.associateWith { prefs.getInt(it, 0) }
    }

    fun save(prayer: String, count: Int) {
        prefs.edit().putInt(prayer, count).apply()
    }

    fun reset() {
        prefs.edit().clear().putString("date", LocalDate.now().toString()).apply()
    }
}

@Composable
fun DhikriApp(store: DhikriStore) {
    var date by remember { mutableStateOf("") }
    var counts by remember { mutableStateOf(prayers.associateWith { 0 }) }
    var selectedPrayer by remember { mutableStateOf("الفجر") }
    var showReset by remember { mutableStateOf(false) }
    var currentScreen by remember { mutableStateOf("الرئيسية") }
    var selectedAdhkarSection by remember { mutableStateOf("أذكار الصباح") }
    var adhkarCounts by remember { mutableStateOf(mutableMapOf<String, Int>()) }

    fun reload() {
        val loaded = store.load()
        date = loaded.first
        counts = loaded.second
    }

    LaunchedEffect(Unit) { reload() }
    val total = counts.values.sum()

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold,
            onPrimary = Forest,
            background = Forest,
            surface = Forest2,
            onSurface = Cream,
            secondary = Gold
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Forest) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
                contentPadding = PaddingValues(top = 24.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("الرئيسية", "مكتبة الأذكار").forEach { screen ->
                            Button(
                                onClick = { currentScreen = screen },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (currentScreen == screen) Gold else Forest2,
                                    contentColor = if (currentScreen == screen) Forest else Cream
                                ),
                                modifier = Modifier.weight(1f)
                            ) { Text(screen, fontSize = 13.sp) }
                        }
                    }
                }
                if (currentScreen == "مكتبة الأذكار") {
                    item {
                        Text("مكتبة الأذكار", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("أذكار مختارة مع عدد التكرار والمصدر", color = Muted, fontSize = 13.sp)
                    }
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            adhkarSections.forEach { section ->
                                FilterChip(
                                    selected = selectedAdhkarSection == section,
                                    onClick = { selectedAdhkarSection = section },
                                    label = { Text(section, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                    items(
                        if (selectedAdhkarSection == "أذكار بعد الصلاة") afterPrayerAdhkar.size
                        else morningEveningAdhkar.size
                    ) { index ->
                        val item = if (selectedAdhkarSection == "أذكار بعد الصلاة")
                            afterPrayerAdhkar[index] else morningEveningAdhkar[index]
                        val count = adhkarCounts[item.title] ?: 0
                        Card(colors = CardDefaults.cardColors(containerColor = Forest2),
                            shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                Text(item.title, color = Gold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text(item.text, color = Cream, fontSize = 17.sp, lineHeight = 29.sp)
                                Spacer(Modifier.height(8.dp))
                                Text("المصدر: ${item.source}", color = Muted, fontSize = 11.sp)
                                Spacer(Modifier.height(10.dp))
                                Row(verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()) {
                                    Text("التكرار: ${item.repetitions}  •  المنجز: $count",
                                        color = Muted, fontSize = 12.sp)
                                    Button(
                                        onClick = {
                                            val next = if (count >= item.repetitions) 0 else count + 1
                                            adhkarCounts = adhkarCounts.toMutableMap().apply { put(item.title, next) }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Forest)
                                    ) { Text(if (count >= item.repetitions) "إعادة" else "تسبيح") }
                                }
                            }
                        }
                    }
                } else {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("السلام عليكم ورحمة الله", color = Muted, fontSize = 13.sp)
                            Text("ذِكري", color = Cream, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                            Text("أذكاري وتسبيحي اليومي", color = Gold, fontSize = 14.sp)
                        }
                        Text("☾", color = Gold, fontSize = 34.sp)
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Forest2),
                        shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp)) {
                            Text("وردك اليومي", color = Gold, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(8.dp))
                            Text(if (date.isBlank()) LocalDate.now().toString() else date,
                                color = Muted, fontSize = 12.sp)
                            Spacer(Modifier.height(14.dp))
                            Text(total.toString(), color = Cream, fontSize = 38.sp,
                                fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth())
                            Text("مجموع التسبيحات اليوم", color = Muted, fontSize = 13.sp,
                                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
                item {
                    Column(horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()) {
                        Text("السبحة الإلكترونية", color = Cream, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Text("التسجيل لصلاة $selectedPrayer", color = Muted, fontSize = 13.sp)
                        Spacer(Modifier.height(14.dp))
                        Box(
                            modifier = Modifier.size(190.dp).border(3.dp, Gold, CircleShape)
                                .padding(9.dp).background(Forest2, CircleShape)
                                .clickable {
                                    val next = (counts[selectedPrayer] ?: 0) + 1
                                    counts = counts + (selectedPrayer to next)
                                    store.save(selectedPrayer, next)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text((counts[selectedPrayer] ?: 0).toString(), color = Cream,
                                    fontSize = 42.sp, fontWeight = FontWeight.Bold)
                                Text("اضغط للتسبيح", color = Gold, fontSize = 13.sp)
                                Icon(Icons.Default.Add, contentDescription = "زيادة التسبيح", tint = Gold)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("كل ضغطة تسجل تسبيحة واحدة للصلاة المختارة",
                            color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center)
                    }
                }
                item {
                    Text("سجل الصلوات الخمس", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                }
                items(prayers.size) { index ->
                    val prayer = prayers[index]
                    val value = counts[prayer] ?: 0
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { selectedPrayer = prayer },
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedPrayer == prayer) Color(0xFF315B49) else Forest2
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(15.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(prayer, color = Cream, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("اضغط لاختيار هذه الصلاة", color = Muted, fontSize = 11.sp)
                            }
                            Text(value.toString(), color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(6.dp))
                            Text("تسبيحة", color = Muted, fontSize = 11.sp)
                        }
                    }
                }
                item {
                    OutlinedButton(
                        onClick = { showReset = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("تصفير سجل اليوم")
                    }
                }
                item {
                    Text("ذِكري • رفيقك في الذكر والطمأنينة", color = Muted,
                        fontSize = 11.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
                }
                }
            }
        }
    }

    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            title = { Text("تصفير سجل اليوم؟") },
            text = { Text("سيتم حذف أعداد التسبيح المسجلة لهذا اليوم فقط.") },
            confirmButton = {
                TextButton(onClick = {
                    store.reset()
                    reload()
                    showReset = false
                }) { Text("تصفير") }
            },
            dismissButton = {
                TextButton(onClick = { showReset = false }) { Text("إلغاء") }
            }
        )
    }
}
