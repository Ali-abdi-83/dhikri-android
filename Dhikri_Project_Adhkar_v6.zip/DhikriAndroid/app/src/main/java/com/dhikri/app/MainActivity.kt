package com.dhikri.app

import android.content.Context
import android.content.BroadcastReceiver
import android.content.Intent
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.provider.Settings
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.util.Calendar
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

private val Forest = Color(0xFF102F29)
private val Forest2 = Color(0xFF1C493C)
private val Gold = Color(0xFFE5C98C)
private val Cream = Color(0xFFF4EEDC)
private val Muted = Color(0xFFB9C9BE)

private val prayers = listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")
private val reminderNames = listOf("أذكار الصباح", "أذكار المساء", "أذكار النوم")
private val reminderDefaults = listOf("07:00", "18:00", "22:00")


private data class DhikrItem(
    val title: String,
    val text: String,
    val repetitions: Int,
    val source: String
)

private val adhkarSections = listOf(
    "أذكار الصباح", "أذكار المساء", "أذكار بعد الصلاة",
    "أذكار النوم", "أذكار الاستيقاظ", "دخول المنزل والخروج منه", "دخول المسجد والخروج منه"
)

private val morningAdhkar = listOf(
    DhikrItem("آية الكرسي", "اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ", 1, "سورة البقرة: 255"),
    DhikrItem("سورة الإخلاص", "قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُنْ لَهُ كُفُوًا أَحَدٌ", 3, "سورة الإخلاص؛ ثلاث مرات صباحاً"),
    DhikrItem("سورة الفلق", "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ۝ مِنْ شَرِّ مَا خَلَقَ ۝ وَمِنْ شَرِّ غَاسِقٍ إِذَا وَقَبَ ۝ وَمِنْ شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ۝ وَمِنْ شَرِّ حَاسِدٍ إِذَا حَسَدَ", 3, "سورة الفلق؛ ثلاث مرات صباحاً"),
    DhikrItem("سورة الناس", "قُلْ أَعُوذُ بِرَبِّ النَّاسِ ۝ مَلِكِ النَّاسِ ۝ إِلَٰهِ النَّاسِ ۝ مِنْ شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ۝ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ۝ مِنَ الْجِنَّةِ وَالنَّاسِ", 3, "سورة الناس؛ ثلاث مرات صباحاً"),
    DhikrItem("سيد الاستغفار", "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي، فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ", 1, "صحيح البخاري"),
    DhikrItem("ذكر الحفظ", "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ", 3, "سنن أبي داود والترمذي"),
    DhikrItem("رضيت بالله رباً", "رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ نَبِيًّا", 3, "سنن أبي داود والترمذي")
)

private val eveningAdhkar = morningAdhkar.map { item ->
    if (item.title == "رضيت بالله رباً") item.copy(source = "ثلاث مرات مساءً؛ سنن أبي داود والترمذي")
    else item.copy(source = item.source.replace("صباحاً", "مساءً"))
}

private val afterPrayerAdhkar = listOf(
    DhikrItem("الاستغفار", "أَسْتَغْفِرُ اللَّهَ", 3, "صحيح مسلم"),
    DhikrItem("دعاء السلام", "اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ", 1, "صحيح مسلم"),
    DhikrItem("التسبيح", "سُبْحَانَ اللَّهِ", 33, "صحيح مسلم"),
    DhikrItem("التحميد", "الْحَمْدُ لِلَّهِ", 33, "صحيح مسلم"),
    DhikrItem("التكبير", "اللَّهُ أَكْبَرُ", 33, "صحيح مسلم"),
    DhikrItem("تمام المائة", "لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ", 1, "صحيح مسلم؛ تمام المائة بعد التسبيح والتحميد والتكبير")
)

private val sleepAdhkar = listOf(
    DhikrItem("دعاء النوم", "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا", 1, "صحيح البخاري"),
    DhikrItem("آية الكرسي", morningAdhkar[0].text, 1, "آية الكرسي؛ ورد فضل قراءتها عند النوم في صحيح البخاري"),
    DhikrItem("آخر آيتين من البقرة", "آمَنَ الرَّسُولُ بِمَا أُنْزِلَ إِلَيْهِ مِنْ رَبِّهِ وَالْمُؤْمِنُونَ ۚ كُلٌّ آمَنَ بِاللَّهِ وَمَلَائِكَتِهِ وَكُتُبِهِ وَرُسُلِهِ لَا نُفَرِّقُ بَيْنَ أَحَدٍ مِنْ رُسُلِهِ ۚ وَقَالُوا سَمِعْنَا وَأَطَعْنَا ۖ غُفْرَانَكَ رَبَّنَا وَإِلَيْكَ الْمَصِيرُ ۝ لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا ۚ لَهَا مَا كَسَبَتْ وَعَلَيْهَا مَا اكْتَسَبَتْ ۗ رَبَّنَا لَا تُؤَاخِذْنَا إِنْ نَسِينَا أَوْ أَخْطَأْنَا ۚ رَبَّنَا وَلَا تَحْمِلْ عَلَيْنَا إِصْرًا كَمَا حَمَلْتَهُ عَلَى الَّذِينَ مِنْ قَبْلِنَا ۚ رَبَّنَا وَلَا تُحَمِّلْنَا مَا لَا طَاقَةَ لَنَا بِهِ ۖ وَاعْفُ عَنَّا وَاغْفِرْ لَنَا وَارْحَمْنَا ۚ أَنْتَ مَوْلَانَا فَانْصُرْنَا عَلَى الْقَوْمِ الْكَافِرِينَ", 1, "آخر آيتين من سورة البقرة؛ صحيح البخاري ومسلم")
)

private val wakeAdhkar = listOf(
    DhikrItem("دعاء الاستيقاظ", "الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ", 1, "صحيح البخاري")
)

private val homeAdhkar = listOf(
    DhikrItem("دخول المنزل", "بِسْمِ اللَّهِ وَلَجْنَا، وَبِسْمِ اللَّهِ خَرَجْنَا، وَعَلَى اللَّهِ رَبِّنَا تَوَكَّلْنَا، ثُمَّ لِيُسَلِّمْ عَلَى أَهْلِهِ", 1, "سنن أبي داود"),
    DhikrItem("الخروج من المنزل", "بِسْمِ اللَّهِ، تَوَكَّلْتُ عَلَى اللَّهِ، وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", 1, "سنن أبي داود والترمذي")
)

private val mosqueAdhkar = listOf(
    DhikrItem("دخول المسجد", "اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ", 1, "صحيح مسلم"),
    DhikrItem("الخروج من المسجد", "اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ", 1, "صحيح مسلم")
)

private fun adhkarForSection(section: String): List<DhikrItem> = when (section) {
    "أذكار الصباح" -> morningAdhkar
    "أذكار المساء" -> eveningAdhkar
    "أذكار بعد الصلاة" -> afterPrayerAdhkar
    "أذكار النوم" -> sleepAdhkar
    "أذكار الاستيقاظ" -> wakeAdhkar
    "دخول المنزل والخروج منه" -> homeAdhkar
    "دخول المسجد والخروج منه" -> mosqueAdhkar
    else -> morningAdhkar
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ReminderNotifications.createChannel(this)
        val store = DhikriStore(this)
        setContent { DhikriApp(store) }
    }

    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (alarm.canScheduleExactAlarms()) {
                reminderNames.forEachIndexed { index, name ->
                    val prefs = getSharedPreferences("dhikri_reminders", Context.MODE_PRIVATE)
                    if (prefs.getBoolean("enabled_$index", false)) ReminderScheduler.schedule(this, index, name)
                }
            }
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val name = intent.getStringExtra("reminder_name") ?: return
        val id = intent.getIntExtra("reminder_id", 0)
        ReminderNotifications.show(context, id, name)
        ReminderScheduler.schedule(context, id, name)
    }
}

class ReminderBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            reminderNames.forEachIndexed { index, name ->
                val prefs = context.getSharedPreferences("dhikri_reminders", Context.MODE_PRIVATE)
                if (prefs.getBoolean("enabled_$index", false)) ReminderScheduler.schedule(context, index, name)
            }
        }
    }
}

object ReminderNotifications {
    private const val CHANNEL_ID = "dhikri_daily_reminders"
    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "تذكيرات ذِكري", NotificationManager.IMPORTANCE_DEFAULT)
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    fun show(context: Context, id: Int, name: String) {
        createChannel(context)
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("حان وقت $name")
            .setContentText("افتح تطبيق ذِكري واقرأ وردك اليومي")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(context).notify(500 + id, notification) } catch (_: SecurityException) { }
    }
}

object ReminderScheduler {
    fun schedule(context: Context, id: Int, name: String) {
        val prefs = context.getSharedPreferences("dhikri_reminders", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled_$id", false)) return
        val time = prefs.getString("time_$id", reminderDefaults[id]) ?: reminderDefaults[id]
        val parts = time.split(":")
        val now = Calendar.getInstance()
        val next = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, parts[0].toInt())
            set(Calendar.MINUTE, parts[1].toInt())
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= now.timeInMillis) add(Calendar.DAY_OF_YEAR, 1)
        }
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("reminder_name", name)
            putExtra("reminder_id", id)
        }
        val pending = PendingIntent.getBroadcast(context, 700 + id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarm.canScheduleExactAlarms()) {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending)
        } else {
            // Fallback on devices where exact-alarm access has not been granted.
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending)
        }
    }
    fun cancel(context: Context, id: Int, name: String) {
        val intent = Intent(context, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(context, 700 + id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
    }
}

data class DailyRecord(val date: String, val counts: Map<String, Int>) {
    val total: Int get() = counts.values.sum()
}

class DhikriStore(context: Context) {
    private val prefs = context.getSharedPreferences("dhikri_daily", Context.MODE_PRIVATE)

    private fun prayerKey(date: String, prayer: String) = "prayer_${date}_$prayer"

    fun load(date: String = LocalDate.now().toString()): Pair<String, Map<String, Int>> {
        // Migrate the V3 current-day counters once, without deleting the adhkar counters.
        val legacyDate = prefs.getString("date", "") ?: ""
        if (legacyDate == date && prefs.getBoolean("v4_migrated", false).not()) {
            val editor = prefs.edit()
            prayers.forEach { prayer ->
                val oldValue = prefs.getInt(prayer, 0)
                if (oldValue > 0 && !prefs.contains(prayerKey(date, prayer))) {
                    editor.putInt(prayerKey(date, prayer), oldValue)
                }
            }
            editor.putBoolean("v4_migrated", true).apply()
        }
        return date to prayers.associateWith { prefs.getInt(prayerKey(date, it), 0) }
    }

    fun save(date: String, prayer: String, count: Int) {
        prefs.edit().putInt(prayerKey(date, prayer), count).apply()
    }

    fun loadAdhkarCounts(): Map<String, Int> = prefs.all
        .filterKeys { it.startsWith("adhkar_") }
        .mapKeys { it.key.removePrefix("adhkar_") }
        .mapValues { (it.value as? Int) ?: 0 }

    fun saveAdhkarCount(title: String, count: Int) {
        prefs.edit().putInt("adhkar_$title", count).apply()
    }

    fun reset(date: String = LocalDate.now().toString()) {
        val editor = prefs.edit()
        prayers.forEach { editor.remove(prayerKey(date, it)) }
        editor.apply()
    }

    fun history(days: Int = 7): List<DailyRecord> = (0 until days).map { offset ->
        val date = LocalDate.now().minusDays(offset.toLong()).toString()
        DailyRecord(date, prayers.associateWith { prefs.getInt(prayerKey(date, it), 0) })
    }
}

@Composable
fun DhikriApp(store: DhikriStore) {
    var date by remember { mutableStateOf("") }
    var counts by remember { mutableStateOf(prayers.associateWith { 0 }) }
    var selectedPrayer by remember { mutableStateOf("الفجر") }
    var showReset by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf(store.history()) }
    var currentScreen by remember { mutableStateOf("الرئيسية") }
    val context = LocalContext.current
    val reminderPrefs = remember { context.getSharedPreferences("dhikri_reminders", Context.MODE_PRIVATE) }
    var reminderEnabled by remember { mutableStateOf(reminderNames.indices.associateWith { reminderPrefs.getBoolean("enabled_$it", false) }) }
    var reminderTimes by remember { mutableStateOf(reminderNames.indices.associateWith { reminderPrefs.getString("time_$it", reminderDefaults[it]) ?: reminderDefaults[it] }) }
    var selectedAdhkarSection by remember { mutableStateOf("أذكار الصباح") }
    var adhkarCounts by remember { mutableStateOf(store.loadAdhkarCounts()) }

    fun reload() {
        val loaded = store.load()
        date = loaded.first
        counts = loaded.second
        history = store.history()
    }

    LaunchedEffect(Unit) { reload() }
    val total = counts.values.sum()

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold,
            onPrimary = Forest,
            background = Forest,
            surface = Forest2,
            onSurface = Cream,
            secondary = Gold
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Forest) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
                contentPadding = PaddingValues(top = 24.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("الرئيسية", "مكتبة الأذكار", "التذكيرات").forEach { screen ->
                            Button(
                                onClick = { currentScreen = screen },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (currentScreen == screen) Gold else Forest2,
                                    contentColor = if (currentScreen == screen) Forest else Cream
                                ),
                                modifier = Modifier.weight(1f)
                            ) { Text(screen, fontSize = 13.sp) }
                        }
                    }
                }
                if (currentScreen == "التذكيرات") {
                    item {
                        Text("التذكيرات اليومية", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("فعّل التنبيهات وحدد الوقت المناسب لكل ورد", color = Muted, fontSize = 13.sp)
                    }
                    items(reminderNames.size) { index ->
                        val name = reminderNames[index]
                        Card(colors = CardDefaults.cardColors(containerColor = Forest2), shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column(Modifier.weight(1f)) {
                                        Text(name, color = Gold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                                        Text("وقت التنبيه: ${reminderTimes[index]}", color = Muted, fontSize = 13.sp)
                                    }
                                    Switch(checked = reminderEnabled[index] == true, onCheckedChange = { enabled ->
                                        reminderPrefs.edit().putBoolean("enabled_$index", enabled).apply()
                                        reminderEnabled = reminderEnabled + (index to enabled)
                                        if (enabled) ReminderScheduler.schedule(context, index, name)
                                        else ReminderScheduler.cancel(context, index, name)
                                    })
                                }
                                Spacer(Modifier.height(8.dp))
                                OutlinedButton(onClick = {
                                    val parts = (reminderTimes[index] ?: reminderDefaults[index]).split(":")
                                    TimePickerDialog(context, { _, hour, minute ->
                                        val value = String.format(java.util.Locale.US, "%02d:%02d", hour, minute)
                                        reminderPrefs.edit().putString("time_$index", value).apply()
                                        reminderTimes = reminderTimes + (index to value)
                                        if (reminderEnabled[index] == true) ReminderScheduler.schedule(context, index, name)
                                    }, parts[0].toInt(), parts[1].toInt(), true).show()
                                }, modifier = Modifier.fillMaxWidth()) { Text("تغيير وقت التنبيه") }
                            }
                        }
                    }
                    item {
                        OutlinedButton(
                            onClick = {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                    val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                        Uri.parse("package:${context.packageName}"))
                                    context.startActivity(intent)
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("تفعيل التنبيهات في وقتها المحدد") }
                        Text("للحصول على تنبيه أدق، اضغط الزر واسمح للتطبيق بالتنبيهات الدقيقة من إعدادات الهاتف. كما يجب السماح بالإشعارات.",
                            color = Muted, fontSize = 12.sp)
                    }
                } else if (currentScreen == "مكتبة الأذكار") {
                    item {
                        Text("مكتبة الأذكار", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text("أذكار مختارة مع عدد التكرار والمصدر", color = Muted, fontSize = 13.sp)
                    }
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(adhkarSections.size) { index ->
                                val section = adhkarSections[index]
                                FilterChip(
                                    selected = selectedAdhkarSection == section,
                                    onClick = { selectedAdhkarSection = section },
                                    label = { Text(section, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                    items(adhkarForSection(selectedAdhkarSection).size) { index ->
                        val item = adhkarForSection(selectedAdhkarSection)[index]
                        val count = adhkarCounts[item.title] ?: 0
                        Card(colors = CardDefaults.cardColors(containerColor = Forest2),
                            shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                                Text(item.title, color = Gold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Text(item.text, color = Cream, fontSize = 17.sp, lineHeight = 29.sp)
                                Spacer(Modifier.height(8.dp))
                                Text("المصدر: ${item.source}", color = Muted, fontSize = 11.sp)
                                Spacer(Modifier.height(10.dp))
                                Row(verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()) {
                                    Text("التكرار: ${item.repetitions}  •  المنجز: $count",
                                        color = Muted, fontSize = 12.sp)
                                    Button(
                                        onClick = {
                                            val next = if (count >= item.repetitions) 0 else count + 1
                                            adhkarCounts = adhkarCounts.toMutableMap().apply { put(item.title, next) }
                                            store.saveAdhkarCount(item.title, next)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Forest)
                                    ) { Text(if (count >= item.repetitions) "إعادة" else "تسبيح") }
                                }
                            }
                        }
                    }
                } else {
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("السلام عليكم ورحمة الله", color = Muted, fontSize = 13.sp)
                            Text("ذِكري", color = Cream, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                            Text("أذكاري وتسبيحي اليومي", color = Gold, fontSize = 14.sp)
                        }
                        Text("☾", color = Gold, fontSize = 34.sp)
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Forest2),
                        shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.fillMaxWidth().padding(18.dp)) {
                            Text("وردك اليومي", color = Gold, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(8.dp))
                            Text(if (date.isBlank()) LocalDate.now().toString() else date,
                                color = Muted, fontSize = 12.sp)
                            Spacer(Modifier.height(14.dp))
                            Text(total.toString(), color = Cream, fontSize = 38.sp,
                                fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth())
                            Text("مجموع التسبيحات اليوم", color = Muted, fontSize = 13.sp,
                                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
                item {
                    Column(horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()) {
                        Text("السبحة الإلكترونية", color = Cream, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        Text("التسجيل لصلاة $selectedPrayer", color = Muted, fontSize = 13.sp)
                        Spacer(Modifier.height(14.dp))
                        Box(
                            modifier = Modifier.size(190.dp).border(3.dp, Gold, CircleShape)
                                .padding(9.dp).background(Forest2, CircleShape)
                                .clickable {
                                    val next = (counts[selectedPrayer] ?: 0) + 1
                                    counts = counts + (selectedPrayer to next)
                                    store.save(date.ifBlank { LocalDate.now().toString() }, selectedPrayer, next)
                                    history = store.history()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text((counts[selectedPrayer] ?: 0).toString(), color = Cream,
                                    fontSize = 42.sp, fontWeight = FontWeight.Bold)
                                Text("اضغط للتسبيح", color = Gold, fontSize = 13.sp)
                                Icon(Icons.Default.Add, contentDescription = "زيادة التسبيح", tint = Gold)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("كل ضغطة تسجل تسبيحة واحدة للصلاة المختارة",
                            color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center)
                    }
                }
                item {
                    Text("سجل الصلوات الخمس", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                }
                items(prayers.size) { index ->
                    val prayer = prayers[index]
                    val value = counts[prayer] ?: 0
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { selectedPrayer = prayer },
                        colors = CardDefaults.cardColors(
                            containerColor = if (selectedPrayer == prayer) Color(0xFF315B49) else Forest2
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(15.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(prayer, color = Cream, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("اضغط لاختيار هذه الصلاة", color = Muted, fontSize = 11.sp)
                            }
                            Text(value.toString(), color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.width(6.dp))
                            Text("تسبيحة", color = Muted, fontSize = 11.sp)
                        }
                    }
                }
                item {
                    Text("ملخص آخر 7 أيام", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                }
                items(history.size) { index ->
                    val record = history[index]
                    Card(colors = CardDefaults.cardColors(containerColor = Forest2),
                        shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically) {
                                Text(record.date, color = Cream, fontWeight = FontWeight.Bold)
                                Text("${record.total} تسبيحة", color = Gold, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(prayers.joinToString("   •   ") { prayer -> "$prayer: ${record.counts[prayer] ?: 0}" },
                                color = Muted, fontSize = 11.sp)
                        }
                    }
                }
                item {
                    OutlinedButton(
                        onClick = { showReset = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("تصفير سجل اليوم")
                    }
                }
                item {
                    Text("ذِكري • رفيقك في الذكر والطمأنينة", color = Muted,
                        fontSize = 11.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
                }
                }
            }
        }
    }

    if (showReset) {
        AlertDialog(
            onDismissRequest = { showReset = false },
            title = { Text("تصفير سجل اليوم؟") },
            text = { Text("سيتم حذف أعداد التسبيح المسجلة لهذا اليوم فقط.") },
            confirmButton = {
                TextButton(onClick = {
                    store.reset(date.ifBlank { LocalDate.now().toString() })
                    reload()
                    showReset = false
                }) { Text("تصفير") }
            },
            dismissButton = {
                TextButton(onClick = { showReset = false }) { Text("إلغاء") }
            }
        )
    }
}
